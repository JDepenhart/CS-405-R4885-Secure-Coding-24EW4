// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

using namespace std; // added namespace std - Jeremy Depenhart

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Added an if statement to catch overflow - Jeremy Depenhart
        /* This checks if result is greater than 0 and if the increment amount is 
        * greater than the max numaric limit of T - result
        */
        if (result >= 0 && increment > (numeric_limits<T>::max() - result))
        {
            // added exception throw - Jeremy Depenhart
            throw overflow_error("ERROR: an overflow has occured \n");
        }
        
        result += increment;
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
       // Added an if statement to catch underflow - Jeremy Depenhart
       // This checks if the decrement amount is less than the min numaric limit of T - result
        if (decrement < (numeric_limits<T>::min() - result))
        {
            // added exception throw - Jeremy Depenhart
            throw underflow_error("ERROR: an underflow has occured \n");
        }

        result -= decrement;
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    cout << "Overflow Test of Type = " << typeid(T).name() << endl;
    // END DO NOT CHANGE

    // Added a try catch statement -Jeremy Depenhart
    // This will try to print the original cout statements and catch overflow_error
    try
    {
        cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
        T result = add_numbers<T>(start, increment, steps);
        cout << +result << endl;

        cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
        result = add_numbers<T>(start, increment, steps + 1);
        cout << +result << endl;
    }
    catch (const overflow_error& error)
    {
        cout << error.what();
    }
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = numeric_limits<T>::max();

    cout << "Underflow Test of Type = " << typeid(T).name() << endl;
    // END DO NOT CHANGE

    // Added a try catch statement -Jeremy Depenhart
    // This will try to print the original cout statements and catch underflow_error
    try 
    {
        cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
        auto result = subtract_numbers<T>(start, decrement, steps);
        cout << +result << endl;

        cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
        result = subtract_numbers<T>(start, decrement, steps + 1);
        cout << +result << endl;
    }
    catch (const underflow_error& error)
    {
        cout << error.what();
    }
}

void do_overflow_tests(const string& star_line)
{
    cout << endl << star_line << endl;
    cout << "*** Running Overflow Tests ***" << endl;
    cout << star_line << endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const string& star_line)
{
    cout << endl << star_line << endl;
    cout << "*** Running Undeflow Tests ***" << endl;
    cout << star_line << endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const string star_line = string(50, '*');

    cout << "Starting Numeric Underflow / Overflow Tests!" << endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    cout << endl << "All Numeric Underflow / Overflow Tests Complete!" << endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu