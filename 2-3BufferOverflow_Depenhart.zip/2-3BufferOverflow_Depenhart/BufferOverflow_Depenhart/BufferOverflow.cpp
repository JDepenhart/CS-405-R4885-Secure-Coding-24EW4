// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	/*
	* SUMMARY: To prevent buffer overflow, I first established a const unsigned int of maxSize
	* and set it to 20 (the original amount in the user_input char array. Instead of using cin >> user_input, 
	* I used cin.getline with the arguments of user_input and maxSize. this method will get the first 20 characters
	* of the user's input and ignore the rest. this prevent buffer overflow. 
	*/

	const unsigned int maxSize = 20;
  
	const std::string account_number = "CharlieBrown42";
	char user_input[maxSize];

	std::cout << "Enter a value: ";
	std::cin.getline(user_input, maxSize);

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
